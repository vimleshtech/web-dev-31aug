import React from 'react';

class Product extends React.Component{

    constructor(){
        super();

        this.state={

            id:11,
            name:'raman',
            gender:'male',
            list:[],
            edit_index:-1
        }
    }

    frm_add=()=>{


        var pname = this.refs.pname.value;
        var price = this.refs.price.value;
        
        var list = this.state.list; //read / assign the state variable to local variable 
        list.push({pname:pname,price:price,ismark:false});

        //list.setState({list:list}) //update state 
        this.setState({list}) //update state 

        console.log(pname+" "+price)
        console.log(this.state.list);

        this.refs.pname.value="";
        this.refs.price.value="";

    }
    frm_del=(i)=>{
 
            //alert(i);

            var list = this.state.list; //read / assign the state variable to local variable 
            list.splice(i,1);//remove the item 
    
            //list.setState({list:list}) //update state 
            this.setState({list}) //update state 
    
    }
    frm_edit=(i)=>{
        
                   //alert(i);
       
                   var list = this.state.list; //read / assign the state variable to local variable 
           
                this.setState({edit_index:i});

                   
                this.refs.pname.value=list[i].pname;
                this.refs.price.value=list[i].price;


           }

           frm_update=()=>{
    
                var list = this.state.list; //read / assign the state variable to local variable 
                var ind =this.state.edit_index;

                var pname = this.refs.pname.value;
                var price = this.refs.price.value;
                
                list[ind].pname = pname;
                list[ind].price = price;

                this.setState({list,edit_index:-1});

 
                        
                this.refs.pname.value="";
                this.refs.price.value="";
                
           }
           frm_check=(i)=>{

            var list = this.state.list; //read / assign the state variable to local variable 
            list[i].ismark = !list[i].ismark;
            
           }
           frm_mark_del=()=>{

            var list = this.state.list.filter(r => r.ismark==false);
            this.setState({list});
            

           }
    render(){

        var data =100;

        return(<div>
            
                <p>
                    Interpolation : {2*4}
                </p>
                <p>
                    Interpolation - Data from variable : {data}
                </p>
                
                

                <p>

                    Data from state : {this.state.id}  | {this.state.name} | {this.state.gender} 
                </p>

                <h1>Form </h1>
                <p>
                    <input type="text"  placeholder="enter product name" ref="pname"/>
            
                </p>
                <p>
                    <input type="text"  placeholder="enter price" ref="price"/>            
                </p>
                
                <p>
                    <input type="button"  value="Add Product" onClick={this.frm_add} />            
                    <input type="button"  value="Update Product" onClick={this.frm_update} />            
                    <input type="button"  value="Ddelete Mark Delete" onClick={this.frm_mark_del} />            

                </p>

            <h1> Product Details </h1>
            <div>
                {this.state.list.map((item,i)=>
                
                            <p key={i}>  {item.pname} | {item.price} 
                            <input type="button" value="Delete" onClick={()=>this.frm_del(i)} />
                            <input type="button" value="Edit"  onClick={()=>this.frm_edit(i)} />
                            <input type="button" value="Mark" onClick={()=>this.frm_check(i)} /> </p> 

                )}
            </div>

            
            </div>)
    }
}

export default Product;